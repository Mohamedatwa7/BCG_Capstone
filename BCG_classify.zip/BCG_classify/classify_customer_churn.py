import pandas as pd
import argparse
from datetime import datetime
import os
import sys
import warnings
from pycaret.classification import load_model, predict_model
from huggingface_hub import InferenceApi, login
import re
import spacy
import time
from collections import Counter, defaultdict
from transformers import pipeline
from datasets import load_dataset
import torch
import numpy as np
import matplotlib.pyplot as plt
import pickle

warnings.filterwarnings('ignore', category=FutureWarning)

def verbose_print(message, is_verbose):
    if is_verbose:
        print(message)

def check_file_format(filename, expected_extension, is_verbose):
    verbose_print(f"Checking format of {filename}...", is_verbose)
    if not filename.endswith(expected_extension):
        print(f"Error: The file '{filename}' is not in the expected {expected_extension} format.")
        sys.exit(1)

def check_file_exists(filename, is_verbose):
    verbose_print(f"Checking if file {filename} exists...", is_verbose)
    if not os.path.exists(filename):
        print(f"Error: The file '{filename}' does not exist. Please provide a valid file path.")
        sys.exit(1)

def check_file_empty(filename, is_verbose):
    verbose_print(f"Checking if file {filename} is empty...", is_verbose)
    if os.path.getsize(filename) == 0:
        print(f"Error: The file '{filename}' is empty. Please provide a non-empty file.")
        sys.exit(1)

def check_required_columns(dataframe, required_columns, filename, is_verbose):
    verbose_print(f"Checking required columns in {filename}...", is_verbose)
    missing_columns = [col for col in required_columns if col not in dataframe.columns]
    if missing_columns:
        print(f"Error: Missing required columns {missing_columns} in {filename}. Please include these columns: {required_columns}")
        sys.exit(1)

def standardize_columns(activity_data, customer_data, complaints_data, is_verbose):
    verbose_print("Standardizing column names...", is_verbose)
    activity_data.columns = activity_data.columns.str.lower().str.replace(' ', '_', regex=False)
    customer_data.columns = customer_data.columns.str.lower().str.replace(' ', '_', regex=False)
    complaints_data.columns = complaints_data.columns.str.lower().str.replace(' ', '_', regex=False)
    return activity_data, customer_data, complaints_data

def process_dates(activity_data, customer_data, is_verbose):
    verbose_print("Processing dates...", is_verbose)
    activity_data['month'] = pd.to_datetime(activity_data['month'], dayfirst=True)
    customer_data['birth_date'] = pd.to_datetime(customer_data['birth_date'])
    customer_data['join_date'] = pd.to_datetime(customer_data['join_date'])
    return activity_data, customer_data

def pivot_activity_data(activity_data, is_verbose):
    verbose_print("Pivoting activity data...", is_verbose)
    activity_pivot = activity_data.pivot_table(
        index='customer_id',
        columns='month',
        values=['data_usage', 'phone_usage', 'use_app'],
        aggfunc='first'
    )
    activity_pivot.columns = ['{}_{}'.format(metric, month) for metric, month in activity_pivot.columns]
    month_order = ['January', 'February', 'March', 'April', 'May', 'June',
                   'July', 'August', 'September', 'October', 'November', 'December']
    month_columns = sorted([col for col in activity_pivot.columns if any(m in col for m in month_order)],
                           key=lambda x: month_order.index(x.split('_')[-1]))
    other_columns = [col for col in activity_pivot.columns if col not in month_columns]
    activity_pivot = activity_pivot[other_columns + month_columns]
    activity_pivot.reset_index(inplace=True)
    return activity_pivot

def add_customer_features(customer_data, is_verbose):
    verbose_print("Adding customer features...", is_verbose)
    customer_data = pd.get_dummies(customer_data, columns=['plan_type'], prefix='plan')
    customer_data['age_at_joining'] = (customer_data['join_date'] - customer_data['birth_date']).dt.days // 365
    reference_date = datetime(2022, 1, 1)
    customer_data['years_on_plan'] = (reference_date - customer_data['join_date']).dt.days // 365
    return customer_data

def extract_complaint_details(complaints_data, is_verbose):
    verbose_print("Extracting complaint details...", is_verbose)
    complaints_data['issue'] = complaints_data['complaint'].str.extract(r'issue: (.*?)(\.|\n)', expand=False)[0]
    complaints_data['action_required'] = complaints_data['complaint'].str.extract(r'unresolved\. (.*?)(\.|\n)', expand=False)[0]
    complaints_data['complaint'] = complaints_data['complaint'].str.replace(r'\s+', ' ', regex=True).str.strip()
    complaints_data['introduction_1'] = complaints_data['complaint'].str.extract(r'^(.*?customer with code )', expand=False)
    complaints_data['customer_id_2'] = complaints_data['complaint'].str.extract(r'code (\d{5})', expand=False)
    complaints_data['introduction_2'] = complaints_data['complaint'].str.extract(r'code \d{5}, (.*?) issue:', expand=False)
    complaints_data['bridge'] = complaints_data['complaint'].str.extract(
        r'(Despite reaching out to customer support.*?unresolved\.)', expand=False
    )
    complaints_data['ending'] = complaints_data['complaint'].str.extract(r'(I kindly.*?prompt response\.)', expand=False)
    return complaints_data

def clean_complaints_data(complaints_data, is_verbose):
    verbose_print("Cleaning complaints data...", is_verbose)
    complaints_data['id_check'] = complaints_data.apply(
        lambda row: 1 if row['customer_id'] == row['customer_id_2'] else 0, axis=1
    )
    if complaints_data['id_check'].nunique() == 1:
        complaints_data = complaints_data.drop(columns=['id_check', 'customer_id_2'])
    columns_to_exclude = ["customer_id", "category", "issue", "action_required"]
    remaining_columns = [col for col in complaints_data.columns if col not in columns_to_exclude]
    columns_to_drop = [col for col in remaining_columns if complaints_data[col].nunique() <= 1]
    complaints_data = complaints_data.drop(columns=columns_to_drop)
    complaints_data = complaints_data.drop(columns=['complaint'])
    return complaints_data

def merge_datasets(activity_data, customer_data, complaints_data, is_verbose):
    verbose_print("Merging datasets...", is_verbose)
    activity_data.set_index('customer_id', inplace=True)
    customer_data.set_index('customer_id', inplace=True)
    complaints_data.set_index('customer_id', inplace=True)

    merged_data_intermediate = customer_data.merge(activity_data, left_index=True, right_index=True, how='left')
    complaints_data['complaint'] = 1
    merged_data = pd.merge(
        merged_data_intermediate,
        complaints_data[['complaint', 'category', 'issue', 'action_required']],
        left_index=True,
        right_index=True,
        how='left'
    )
    merged_data['complaint'].fillna(0, inplace=True)
    merged_data['complaint'] = merged_data['complaint'].astype(int)
    merged_data['issue'].fillna('No issue', inplace=True)
    merged_data['action_required'].fillna('No action required', inplace=True)
    merged_data.reset_index(inplace=True)
    return merged_data


def create_complaints_analysis_dataset(complaints_filename):
    """
    Process and analyze complaints data.
    """
    try:
        complaints_data = pd.read_excel(complaints_filename)
        complaints_data.columns = complaints_data.columns.str.lower().str.replace(' ', '_', regex=False)
        complaints_data.rename(columns={'complaint': 'complaint_text'}, inplace=True)
        token = os.getenv("HUGGINGFACE_TOKEN")

        nlp = spacy.load("en_core_web_sm", disable=["ner", "parser"])

        def replace_user_ids(text):
            """Replace 5-digit user IDs with [USER ID]"""
            return re.sub(r'\b\d{5}\b', '[USER ID]', text)

        def split_into_brackets(text):
            """Split text into sub-phrases using common separators, including newlines and periods."""
            text = re.sub(r'\s+', ' ', text) 
            return [p.strip() for p in re.split(r'[.,:;\-\n]', text) if p.strip()]

        def extract_phrases(merged_data):
            all_phrases = []
            phrase_category_map = defaultdict(set)

            for _, row in merged_data.iterrows():
                category = row['category']
                for phrase in row['bracket_phrases']:
                    all_phrases.append(phrase)
                    phrase_category_map[phrase].add(category)

            phrase_counts = Counter(all_phrases)
            total_complaints = len(merged_data)

            general_phrases = {
                phrase for phrase, cats in phrase_category_map.items()
                if len(cats) > 1 and 0.02 < phrase_counts[phrase] / total_complaints <= 0.9
            }

            category_phrases = {phrase for phrase, cats in phrase_category_map.items() if len(cats) == 1}

            merged_data['general_phrases'] = merged_data['bracket_phrases'].apply(
                lambda phrases: [p for p in phrases if p in general_phrases]
            )
            merged_data['category_phrases'] = merged_data['bracket_phrases'].apply(
                lambda phrases: [p for p in phrases if p in category_phrases]
            )

            return merged_data

        def process_complaints(merged_data):
            start_time = time.time()

            merged_data['temp_complaint'] = merged_data['complaint_text'].apply(replace_user_ids)
            merged_data['bracket_phrases'] = merged_data['temp_complaint'].apply(split_into_brackets)
            merged_data = extract_phrases(merged_data)
            merged_data.drop(columns=['temp_complaint', 'bracket_phrases'], inplace=True)

            return merged_data

        complaint_analysis = process_complaints(complaints_data)
        return complaint_analysis

    except Exception as e:
        print(f"An error occurred while analyzing complaints: {e}")
        sys.exit(1)


def analyze_complaints_features(complaint_analysis, feature_model_path):
    """
    Analyze complaints by extracting features using LLM and SpaCy models.

    Args:
        complaints_df (pd.DataFrame): DataFrame containing complaints data with `category_phrases` column.
        feature_model_path (str): Path to the pre-trained feature model file (pickle format).

    Returns:
        pd.DataFrame: Updated DataFrame with extracted features and merged results.
    """
    try:
       
        llm_pipeline = pipeline("text2text-generation", model="google/flan-t5-base")
        nlp = spacy.load("en_core_web_sm")

        feature_prompts = {
            "issue_resolved": "Was the issue resolved?",
            "product_related": "Does the user have bad connection or interruptions?",
            "refund_or_correction_needed": "Is the customer charged or billed wrongly?"
        }

        def detect_past_tense(text):
            """Detects whether an issue is described in the past, assuming persistence otherwise."""
            doc = nlp(text)

            if re.search(r"has\s?.?been|have\s?.?been", text.lower()):
                return False  

            past_count = sum(1 for token in doc if token.tag_ in ["VBD", "VBN"])
            total_verbs = sum(1 for token in doc if token.pos_ == "VERB")

            return past_count / total_verbs > 0.5 if total_verbs > 0 else False

        def extract_features(df):
            """Extracts features efficiently by processing unique phrases only."""
            start_time = time.time()

            unique_phrases = df["category_phrases"].dropna().unique()
            results = {}

            for text in unique_phrases:
                feature_values = {}

                for feature, prompt in feature_prompts.items():
                    input_prompt = f"{prompt} Only answer 'Yes' or 'No'. Context: {text}"
                    try:
                        response = llm_pipeline(input_prompt, max_length=5, do_sample=False)[0]['generated_text'].strip().lower()
                        feature_values[feature] = response in ["yes", "true"] 
                    except Exception as e:
                        feature_values[feature] = None  

                feature_values["issue_not_persistent"] = detect_past_tense(text)

               
                results[text] = feature_values

            features_df = pd.DataFrame.from_dict(results, orient="index").reset_index()
            features_df.rename(columns={"index": "category_phrases"}, inplace=True)

            return features_df

        if not os.path.exists(feature_model_path):
            raise FileNotFoundError(f"Feature model file '{feature_model_path}' not found.")
        with open(feature_model_path, "rb") as file:
            trained_features = pickle.load(file)

        if "category_phrases" not in complaint_analysis.columns:
            raise ValueError("⚠️ The dataset must contain a 'category_phrases' column!")

        def clean_text(text):
            """Ensures all category_phrases are consistently formatted."""
            if isinstance(text, list):
                return " ".join(map(str, text))
            return str(text).strip().lower()

        trained_features["category_phrases"] = trained_features["category_phrases"].apply(clean_text)
        complaint_analysis["category_phrases"] = complaint_analysis["category_phrases"].apply(clean_text)

        classified_features = extract_features(complaint_analysis[["category_phrases"]])

        complaint_analysis = complaint_analysis.merge(classified_features, on="category_phrases", how="left")

        for col in classified_features.columns:
            if f"{col}_x" in complaint_analysis.columns and f"{col}_y" in complaint_analysis.columns:
                complaint_analysis[col] = complaint_analysis[f"{col}_x"].combine_first(complaint_analysis[f"{col}_y"])
                complaint_analysis.drop(columns=[f"{col}_x", f"{col}_y"], inplace=True)

        return complaint_analysis

    except Exception as e:
        print(f"An error occurred during feature analysis: {e}")
        sys.exit(1)

def generate_merged_complaints(merged_data, complaint_analysis, output_file="merged_complaints.csv"):
    """
    Generate a dataset with enriched complaint-related metrics and summaries.

    Args:
        merged_data (pd.DataFrame): The merged dataset containing customer IDs and other features.
        complaint_analysis (pd.DataFrame): The complaint analysis dataset containing issue details.
        output_file (str): Path to save the resulting merged complaints dataset.

    Returns:
        pd.DataFrame: The updated dataset enriched with complaint-related metrics and summaries.
    """
    try:
        merged_complaints = merged_data.copy()
        merged_complaints['no_unresolved_issues'] = merged_complaints['customer_id'].map(
            complaint_analysis[complaint_analysis['issue_resolved'] == False]['customer_id'].value_counts()
        ).fillna(0).astype(int)

        merged_complaints['no_resolved_issues'] = merged_complaints['customer_id'].map(
            complaint_analysis[complaint_analysis['issue_resolved'] == True]['customer_id'].value_counts()
        ).fillna(0).astype(int)
        unresolved_issues = complaint_analysis[complaint_analysis['issue_resolved'] == False]

        for feature in ['product_related', 'refund_or_correction_needed', 'issue_not_persistent']:
            merged_complaints[f'count_{feature}'] = merged_complaints['customer_id'].map(
                unresolved_issues.groupby('customer_id')[feature].sum()
            ).fillna(0).astype(int)

        merged_data['issue_summary'] = merged_data['customer_id'].map(
            unresolved_issues.groupby('customer_id')['category_phrases'].apply(lambda x: ' | '.join(map(str, x)))  
        ).fillna('')

        merged_data['sentiment_summary'] = merged_data['customer_id'].map(
            unresolved_issues.groupby('customer_id')['general_phrases'].apply(lambda x: ' | '.join(map(str, x)))  
        ).fillna('')

        merged_complaints.to_csv(output_file, index=False)

        return merged_complaints

    except Exception as e:
        print(f"An error occurred while generating merged complaints: {e}")
        raise



def preprocess_merged_data(merged_data, verbose=False):
    """
    Preprocess the merged dataset by applying transformations, 
    creating quarterly data usage metrics, and cleaning up columns.

    Args:
        merged_data (pd.DataFrame): The merged dataset containing all input data.
        verbose (bool): Flag to enable or disable verbose logging.

    Returns:
        pd.DataFrame: The preprocessed dataset ready for prediction.
        pd.Series: The extracted customer IDs for later reattachment.
    """
    try:
        if verbose:
            print("Starting preprocessing of merged data...")

        merged_data[['plan_pay-as-you-go', 'plan_postpaid', 'plan_prepaid']] = merged_data[
            ['plan_pay-as-you-go', 'plan_postpaid', 'plan_prepaid']
        ].astype(int)
        
        customer_ids = merged_data['customer_id']

        merged_data.drop(columns=['customer_id', 'category', 'plan_type', 'app_usage_bins', 'phone_usage_bins',
                                  'join_quarter', 'join_month', 'category', 'issue', 'action_required',
                                  'join_quarter_transformed'], inplace=True, errors='ignore')

        merged_data_test = merged_data.copy()

        data_usage_cols = [col for col in merged_data_test.columns if "data_usage" in col]
        data_usage_df = merged_data_test[data_usage_cols].copy()

        data_usage_df.columns = pd.to_datetime(data_usage_df.columns.str.extract(r'(\d{4}-\d{2}-\d{2})')[0])

        trimester_map = {
            1: "quarter_1", 2: "quarter_1", 3: "quarter_1",
            4: "quarter_2", 5: "quarter_2", 6: "quarter_2",
            7: "quarter_3", 8: "quarter_3", 9: "quarter_3",
            10: "quarter_4", 11: "quarter_4", 12: "quarter_4"
        }
        data_usage_df = data_usage_df.groupby(data_usage_df.columns.month.map(trimester_map), axis=1).mean()
        data_usage_df.columns = [f'data_usage_{col}' for col in data_usage_df.columns]

        merged_data_test = pd.concat([merged_data_test, data_usage_df], axis=1)

        merged_data_test.drop(columns=['age_at_joining', 'current_age', 'years_on_plan', 'monthly_avg_phone',
                                       'monthly_avg_data', 'plan_postpaid'], inplace=True, errors='ignore')

        data_usage_monthly_cols = [col for col in merged_data_test.columns if col.startswith('data_usage_20')]
        columns_to_drop = []
        columns_to_drop.extend(data_usage_monthly_cols)
        merged_data_test.drop(columns=columns_to_drop, inplace=True, errors='ignore')

        merged_data = merged_data_test

        if verbose:
            print("Preprocessing completed successfully.")

        return merged_data, customer_ids

    except Exception as e:
        print(f"An error occurred while preprocessing the merged data: {e}")
        sys.exit(1)


def generate_churn_predictions(preprocessed_data, model_path, output_predictions_file, customer_ids, verbose=False):
    """
    Generate churn predictions using the pre-trained PyCaret model and modify output format.

    Args:
        preprocessed_data (DataFrame): The preprocessed dataset to predict on.
        model_path (str): Path to the pre-trained PyCaret model file.
        output_predictions_file (str): Path to save the final predictions CSV file.
        customer_ids (Series): Series containing the customer IDs to be included in the output.
        verbose (bool): Flag to enable or disable verbose logging.

    Returns:
        DataFrame: Returns the predictions DataFrame.
    """
    try:
        if verbose:
            print(f"Loading the pre-trained model from: {model_path}")

        pre_trained_model = load_model(model_path)
        if verbose:
            print("Model loaded successfully")

        if verbose:
            print("Making predictions on the provided dataset...")
        predictions = predict_model(pre_trained_model, data=preprocessed_data)

        predictions_with_ids = pd.concat([customer_ids.reset_index(drop=True), predictions], axis=1)
        predictions_with_ids = predictions_with_ids[['customer_id', 'prediction_label']]

        predictions_with_ids['prediction_label'] = predictions_with_ids['prediction_label'].replace({1: 'Churn', 0: 'No churn'})
        predictions_with_ids.rename(columns={'prediction_label': 'churn_in_3mos'}, inplace=True)

        predictions_with_ids.to_csv(output_predictions_file, index=False)
        print(f"Predictions saved successfully to: {output_predictions_file}")

        return predictions_with_ids

    except Exception as e:
        print(f"An error occurred while generating churn predictions: {e}")
        sys.exit(1)

def main():
    try:
        parser = argparse.ArgumentParser(description="Generate churn predictions from input data.")
        parser.add_argument('--activity', type=str, required=True, help="Path to the activity data CSV file")
        parser.add_argument('--customer', type=str, required=True, help="Path to the customer data CSV file")
        parser.add_argument('--complaints', type=str, required=True, help="Path to the complaints data Excel file")
        parser.add_argument('--model', type=str, required=True, help="Path to the pre-trained PyCaret model")
        parser.add_argument('--features', type=str, required=True, help="Path to the pre-trained feature model file for complaints analysis")
        parser.add_argument('--output', type=str, required=True, help="Path to save the churn predictions CSV file")
        parser.add_argument('--verbose', action='store_true', help="Enable verbose output")

        args = parser.parse_args()
        activity_filename = args.activity
        customer_filename = args.customer
        complaints_filename = args.complaints
        model_path = args.model
        feature_model_path = args.features
        output_predictions_file = args.output
        is_verbose = args.verbose

        verbose_print("Verbose mode is enabled.", is_verbose)

        check_file_format(activity_filename, '.csv', is_verbose)
        check_file_format(customer_filename, '.csv', is_verbose)
        check_file_format(complaints_filename, '.xlsx', is_verbose)
        check_file_exists(activity_filename, is_verbose)
        check_file_exists(customer_filename, is_verbose)
        check_file_exists(complaints_filename, is_verbose)
        check_file_empty(activity_filename, is_verbose)
        check_file_empty(customer_filename, is_verbose)
        check_file_empty(complaints_filename, is_verbose)

        verbose_print("All input files are verified.", is_verbose)

        try:
            verbose_print("Reading activity data...", is_verbose)
            activity_data = pd.read_csv(activity_filename)
        except pd.errors.EmptyDataError:
            print(f"Error: The file '{activity_filename}' is corrupt or not in a valid CSV format.")
            sys.exit(1)
        except pd.errors.ParserError:
            print(f"Error: The file '{activity_filename}' could not be parsed. Ensure it is in a valid CSV format.")
            sys.exit(1)
        except Exception as e:
            print(f"Error: Failed to read the activity file. {e}")
            sys.exit(1)
        try:
            verbose_print("Reading customer data...", is_verbose)
            customer_data = pd.read_csv(customer_filename)
        except pd.errors.EmptyDataError:
            print(f"Error: The file '{customer_filename}' is corrupt or not in a valid CSV format.")
            sys.exit(1)
        except pd.errors.ParserError:
            print(f"Error: The file '{customer_filename}' could not be parsed. Ensure it is in a valid CSV format.")
            sys.exit(1)
        except Exception as e:
            print(f"Error: Failed to read the customer file. {e}")
            sys.exit(1)
        try:
            verbose_print("Reading complaints data...", is_verbose)
            complaints_data = pd.read_excel(complaints_filename)
        except ValueError:
            print(f"Error: The file '{complaints_filename}' could not be read. Ensure it is a valid Excel file (.xlsx).")
            sys.exit(1)
        except Exception as e:
            print(f"Error: Failed to read the complaints file. {e}")
            sys.exit(1)

        activity_data, customer_data, complaints_data = standardize_columns(activity_data, customer_data, complaints_data, is_verbose)
        activity_data, customer_data = process_dates(activity_data, customer_data, is_verbose)
        activity_data = pivot_activity_data(activity_data, is_verbose)
        customer_data = add_customer_features(customer_data, is_verbose)
        complaints_data = extract_complaint_details(complaints_data, is_verbose)
        complaints_data = clean_complaints_data(complaints_data, is_verbose)
        merged_data = merge_datasets(activity_data, customer_data, complaints_data, is_verbose)
        merged_data.to_excel("merged_data.xlsx", index=False)

        verbose_print("Processing completed successfully.", is_verbose)
        
        verbose_print("Processing complaints data...", is_verbose)
        try:
            complaint_analysis = create_complaints_analysis_dataset(complaints_filename)
            verbose_print("Complaints data processing completed.", is_verbose)

        except Exception as e:
            print(f"Error while processing complaints data: {e}")
            sys.exit(1)

        verbose_print("Analyzing complaints features using LLM and SpaCy...", is_verbose)
        try:
            complaints_analyzed = analyze_complaints_features(complaint_analysis, feature_model_path)
            verbose_print("Complaints feature analysis (step 2) completed.", is_verbose)

        except Exception as e:
            print(f"Error while analyzing complaints features (step 2): {e}")
            sys.exit(1)
       
        try:
            merged_complaints = generate_merged_complaints(
                merged_data=merged_data,
                complaint_analysis=complaints_analyzed,
                output_file="merged_complaints.csv"  
            )

        except Exception as e:
            print(f"Error while generating merged complaints: {e}")
        
        verbose_print("Preprocessing merged data...", is_verbose)
        try:
            preprocessed_data, customer_ids = preprocess_merged_data(merged_data, verbose=is_verbose)

            verbose_print("Merged data preprocessing completed successfully.", is_verbose)
        except Exception as e:
            print(f"Error during preprocessing of merged data: {e}")
            sys.exit(1)

        verbose_print("Generating churn predictions...", is_verbose)
        try:
            predictions = generate_churn_predictions(
                preprocessed_data=preprocessed_data,  
                model_path="model",               
                output_predictions_file=output_predictions_file,  
                customer_ids=customer_ids,          
                verbose=is_verbose                 
            )
            verbose_print("Churn predictions generated successfully.", is_verbose)

        except Exception as e:
            print(f"Error during churn prediction: {e}")
            sys.exit(1)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
