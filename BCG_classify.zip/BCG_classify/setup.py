import subprocess
import sys

def install(package):
    """
    Installs the specified package using pip.
    """
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])


# List of required packages
packages = [
    'pandas>=1.5,<2.1',          # Data manipulation and analysis
    'numpy>=1.24',               # Numerical operations
    'openpyxl>=3.0.9',           # Reading and writing Excel files
    'pycaret>=3.0',              # Machine learning library
    'scikit-learn>=1.0',         # Core library for ML algorithms
    'huggingface-hub>=0.11.1',   # Hugging Face Hub for accessing APIs
    'spacy>=3.4',                # Natural language processing
    'torch>=1.12',               # Deep learning framework
    'transformers>=4.25',        # Hugging Face Transformers library
    'datasets>=2.9.0',           # Hugging Face Datasets library
    'matplotlib>=3.5',           # Data visualization
    'argparse',                  # Command-line argument parsing (built-in for Python 3.2+)
]

if __name__ == "__main__":
    for package in packages:
        try:
            print(f"Installing {package}...")
            install(package)
            print(f"{package} installed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Failed to install {package}. Error: {e}")
            sys.exit(1)

    print("All necessary libraries are installed. You can now run the main script.")
